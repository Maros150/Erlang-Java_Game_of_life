import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;


public class Aplet extends JApplet{

	static JApplet aplet;
	int size = Config.size();
	
	public void init(){
	
		aplet = this;
		aplet.setSize(Config.frameSizeX+20, Config.frameSizeY+20);
		aplet.setBackground(Color.RED);
	
	}
	public void paint(Graphics g){
		
		drawTrack(g);
	}
	public void drawTrack(Graphics g){
		
		for(int i=0;i<Plansza.plansza.length;i++){
			for(int j=0;j<Plansza.plansza[0].length;j++){
				
				if(Plansza.plansza[i][j])
					g.setColor(Color.WHITE);
				else 
					g.setColor(Color.BLACK);
			
				g.fillRect(size*j+j+1, size*i+i+1, size, size);
			}
		}
	}
	
}
