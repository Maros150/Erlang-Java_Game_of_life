
public class Config {

	static int sizeOfMapX=FirstWindow.returnX();
	static int sizeOfMapY=FirstWindow.returnY();
	static int frameSizeX = sizeOfMapX*size()+sizeOfMapX+1;
	static int frameSizeY = sizeOfMapY*(size()+1)+1;
	
	public static int size(){
		
		int i;
		if(sizeOfMapX>sizeOfMapY)
			i = 400/sizeOfMapX;
		else
			i = 400/sizeOfMapY;
		
		if(i>=10)
			return i;
		else
			return 10;
		
	}
}
