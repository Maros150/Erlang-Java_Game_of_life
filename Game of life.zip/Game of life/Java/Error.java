import javax.swing.JFrame;
import javax.swing.JLabel;


public class Error extends JFrame{

	JFrame frame = this;
	
	Error(String s){
		frame.setBounds(300, 200, 350, 75);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setTitle("                     BŁĄD");
		 
		s = s.toUpperCase();
		JLabel message = new JLabel(s);
		message.setBounds(5, 15, 350, 20);
		message.setVisible(true);
		frame.getContentPane().add(message);
		
	}
}
