import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class FirstWindow extends JFrame{
	
	private JFrame frame;
	static final JTextField sizeX = new JTextField();
	static final JTextField sizeY = new JTextField();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstWindow window = new FirstWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public FirstWindow() {
		initialize();
	}

	private void initialize() {
		
		
		frame = new JFrame("Wymiary planszy");
		frame.setBounds(400, 200, 300, 50);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		
		JButton start = new JButton("START");
		start.setBounds(200, 17, 85, 20);
		frame.getContentPane().add(start);
		
		start.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				Serwer serwer = new Serwer();
				new Thread(serwer).start();; 
			}
		});
		
		
		sizeX.setBounds(20, 15, 50, 25);
		frame.getContentPane().add(sizeX);
		
		
		sizeY.setBounds(120, 15, 50, 25);
		frame.getContentPane().add(sizeY);
		
		JLabel x = new JLabel("X");
		x.setBounds(90, 22, 10, 10);
		x.setVisible(true);
		frame.getContentPane().add(x);
		
	}
	static int returnX(){
		return Integer.parseInt(sizeX.getText());
	}
	static int returnY(){
		return Integer.parseInt(sizeY.getText());
	}

}
