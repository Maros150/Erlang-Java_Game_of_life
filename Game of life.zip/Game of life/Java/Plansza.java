
public class Plansza {
	
	static boolean[][] plansza = new boolean[Config.sizeOfMapY][Config.sizeOfMapX];
	
	static void setPlansza(int x, int y){
		
			plansza[y][x]= !plansza[y][x];
	}
}
