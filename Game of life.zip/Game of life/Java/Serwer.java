import java.io.IOException;

import com.ericsson.otp.erlang.*;
 
public class Serwer implements Runnable{
    

	@Override
	public void run() {
		
		try{
			OtpNode node = new OtpNode("java");
			OtpMbox mbox = node.createMbox("echo");
       
			Frame frame = new Frame();
			
			int k = 0;
			while (true) {
            
				OtpErlangObject message = mbox.receive();
				String mes = message.toString();
            
				int i=1;
				while(mes.charAt(i)!=',')
					i++;
				int X = Integer.valueOf(mes.substring(1, i));
				int Y = Integer.valueOf(mes.substring(i+1, mes.length()-1));
                    
				Plansza.setPlansza(X-1, Y-1);
            
				frame.repaint();
			}
		}
		catch (IOException e){
			new Error("Brak działającego węzła erlangowego");
		}
		catch(Exception e){}
    }
}