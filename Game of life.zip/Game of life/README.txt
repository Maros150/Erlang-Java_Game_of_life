KOMPILACJA PROGRAMU :

I Najpierw należy skompilować program w javie
	.../Game of life/Java$ javac -cp jinterface-1.5.6.jar *.java
	.../Game of life/Java$ jar cfm Game.jar MANIFEST.MF *.class jinterface-1.5.6.jar
II Następnie odpalić dowolny węzeł erlanga 
	erl -sname node
III W pliku 'komorka.erl' w przedostatniej lini 
	{echo,java@} ! {X,Y},
    należy po '@' wpisać to samo co znajduje się w utworzonym węźlę po tym znaku i zapisać plik
IV Skompilować dwa moduły w utworzonym węźle 
	c(serwer).
	c(komorka).

URUCHOMIENIE PROGRAMU

I Tworzymy węzęł erlanga
	erl -sname node
II Uruchamiamy interfejs graficzny w javie
	java -jar ./Java/Game.jar &       - w pierwszym oknie podajemy rozmiar planszy na jakiej chcemy uruchomić grę
III W uruchomionym węźle uruchamiamy program
	Pid = serwer:start(rozmiar_planszy_X,rozmiar_planszy_Y).  - podajac takie same wymiary planszy jak w uruchomionym programie w Javie
IV Zatrzymanie programu 
	Pid ! stop.

MODYFIKACJA DZIAŁANIA PROGRAMU

Możliwa jest zmiana szybkości działania programu. Aby zwiększyć lub zmniejszyć czas między kolejnymi iteracjami należy w pliku 'serwer.erl' w lini nr 30 zmienić podaną liczbę milisekund oraz ponownie skompilować ten moduł. 
